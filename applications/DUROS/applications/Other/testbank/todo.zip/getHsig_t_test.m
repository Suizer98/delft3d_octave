%GETHSIG_T_test test routine for getHsig_t
clear; close all; clc
ids = 1:4;
WL_t = 3:.25:9;
linespec = {'b', 'k', 'r', ones(1,3)*.6};
FigureTitle = 'Test getHsig_t';
set(0,'Units','pixels') 
position = get(0,'ScreenSize') + [0 30 0 -97];
figure('Position',position,'NumberTitle','off',...
    'Name',FigureTitle,...
    'WindowStyle','docked',...
    'Color','w');

for id = ids
%% Input:
    if id == 1
        text = 'Den Helder';
        [a, b, c, d, e] = deal(9.43, .6, .68, 7, 1.26);
    elseif id == 2
        text = 'IJmuiden';
        [a, b, c, d, e] = deal(5.88, .6, .0254, 7, 2.77);
    elseif id == 3
        text = 'Hoek van Holland';
        [a, b, c, d, e] = deal(4.35, .6, .0008, 7, 4.67);
    elseif id == 4
        text = 'Hoek van Holland (old relation)';
        [a, b, c, d, e] = deal(4.82, .6, .0063, 7, 3.13);
    end
%% Calculate:
    Hsig_t = getHsig_t(WL_t, a, b, c, d, e);
    legendtext{id} = [text, ' (', double2evalstr(a, b, c, d, e), ')']; %#ok<AGROW>
    
%% Visualize results:
    plot(WL_t, Hsig_t, 'Color', linespec{id}, 'LineWidth', 2.5)
    hold on
end
title('Figure 3.9, report A1414/H4357 (see also Table 3.8)')
xlabel('Water level (WL_t) w.r.t. NAP [m]');
ylabel('Mean wave height (\mu_{Hsig_t}) [m]','Rotation',270,'VerticalAlignment','top');
axis([2 10 0 16])
legend(legendtext{ids},2)
grid on