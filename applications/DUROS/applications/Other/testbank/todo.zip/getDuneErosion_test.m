function result = getDuneErosion_test(method, ids)

getdefaults('ids', 1:5, 0,'method','VTV2006',1);

dbstate off
dbstate on
dbstop if error

fun = 'getDuneErosion';
switch method
    case 'DUROS'
        DuneErosionSettings('set','Plus', '');
        DuneErosionSettings('set','AdditionalErosion', false);
        DuneErosionSettings('set','BoundaryProfile', false);
    case 'DUROS-plus'
        DuneErosionSettings('set','Plus', '-plus');
        DuneErosionSettings('set','AdditionalErosion', false);
        DuneErosionSettings('set','BoundaryProfile', false);
    case 'TAW1984'
        DuneErosionSettings('set','Plus', '');
        DuneErosionSettings('set','AdditionalVolume', '-20-.25*Volume');       
    case 'VTV2006'
        DuneErosionSettings('set','Plus', '-plus');
        DuneErosionSettings('set','AdditionalVolume','min([-20,.25*Volume])');       
    otherwise
        return
end
tic
for id = ids
    
%% Input:
    [xInitial, zInitial, D50, WL_t, Hsig_t, Tp_t] = getCase_getDuneErosion(id);
    inputVariables = getInputVariables(fun);
    inputstring = [];
    for i = 1:length(inputVariables)
        inputstring = [inputstring inputVariables{i} ', '];
    end
    inputstring = inputstring(1:end-2);
    
%% Calculate:
    try
        if dbstate && (strcmp(method,'DUROS') || strcmp(method,'DUROS-plus'))
            dbPlotDuneErosion('new');
        end
%         result(id,:) = getDuneErosion_VTV2006(xInitial, zInitial, D50, WL_t, Hsig_t, Tp_t, n_d); %#ok<AGROW>
        result(id,:) = eval([fun '(' inputstring ');']); %#ok<AGROW>
        DuneErosionSettings('set', 'n_d',1);    %vertical scale factor

    catch
        DuneErosionSettings('set', 'n_d',1);    %vertical scale factor
        s = lasterror;
        if strcmp(s.message, 'Subscripted assignment dimension mismatch.')
            clear result
            result(id,:) = eval([fun '(' inputstring ');']); %#ok<AGROW>
        else
            fprintf('\nWhen evaluating test case %.0f\n',id);
            fileseplocations = strfind(s.stack(1).file, filesep); % find positions of file separators
            linestr=['<a href="error:' s.stack(1).file ',' num2str(s.stack(1).line) ',1">' s.stack(1).file(fileseplocations(end)+1:end) '</a>'];
            fprintf('In file %s at line %.0f an error occured:\n%s\n',linestr, s.stack(1).line, s.message)
            return
        end
    end

    
%% Visualize results:
    for i = 1 : length(result(id,:))
        if isfield(result(id,i).info,'precision')
           disp([result(id,i).info.ID,': Accuracy: ' num2str(result(id,i).info.precision,'%02.4f') ' NrIter: ' num2str(result(id,i).info.iter)]);
        end
        if ~isempty(result(id,i).info.ID)
            if ismember({result(id,i).info.ID},'Additional Erosion')
                disp (['Xp = ' num2str(result(id,i).xActive(find(result(id,i).z2Active == WL_t, 1 )),'%.2f'),' m'])
                disp (['Xr = ' num2str(result(id,i).xActive(1),'%.2f'),' m'])
            end
        end
   end
   disp(' ') 
   plotDuneErosion(result(id,:), figure)
end
toc
