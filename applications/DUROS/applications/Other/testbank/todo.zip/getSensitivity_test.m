%GETSENSITIVITY_TEST test routine for getSensitivity
clear; close all; clc
ids = 1:5;
tic
for id = ids

%% Input:
    fun = 'getDuneErosion_DUROS';
    AdditionalCommand = '.625 - result(end).xActive(1)';
    defaultInputs = 'defaultInputs.txt';
    if id==1
        values = 4.5:.25:6;
        variableName = 'WL_t';
        label = 'Water level w.r.t. NAP [m]';
    end
    if id==2
        values = 6.5:.5:9.5;
        variableName = 'Hsig_t';
        label = 'Significant wave height [m]';
    end
    if id==3
        values = (175:25:300)*1e-6;
        variableName = 'D50';
        label = 'Grain size [m]';
    end
    if id==4
        values = -150:50:150;
        variableName = 'ProfileFluct';
        label = 'Profile fluctuation [m^3/m^1]';
    end
    if id==5
        values = 12:20;
        variableName = 'Tp_t';
        label = 'Peak wave period [s]';
    end

%% Calculate:
    resultvalues = getSensitivity(values, fun, variableName, defaultInputs, AdditionalCommand);

%% Visualize results:
    if id == min(ids)
        figure('NumberTitle','off',...
            'Name','Test getSensitivity',...
            'Color','w');
        NrFigureRows = ceil(sqrt(length(ids)));
        if NrFigureRows*(NrFigureRows-1)>length(ids)
            NrFigureColumns = NrFigureRows-1;
        else
            NrFigureColumns = NrFigureRows;
        end
    end
    subplot(NrFigureRows, NrFigureColumns, id)
    plot(values, resultvalues, '-o')
    grid on
    xlabel(label)
    ylabel('Retreat distance [m]','Rotation',270,'VerticalAlignment','top')
end