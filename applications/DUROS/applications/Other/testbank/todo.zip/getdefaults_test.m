function [x, y, z, n, log] = getdefaults_test

%% clear all variables and clear command window
clear all
clc

%% Reset message
writemessage('init');

%% turn off or on input check (off should give an error message)

getdefaults off
getdefaults on

%% check input. Only a and b are specified. c and d will be set.

vars={'x','y','z','n'};
defaults={1,[2,4,6],{'Test','text'},{1}};
disptext=[1 1 1 1];

%
% % getdefaults(variables,default_values,display_ind);
%

% getdefaults(vars,defaults,disptext);

%
% % getdefaults(var_1,def_1,disp_1,var_2,def_2,disp_2,...);
%

getdefaults('x',1,1,'y',[10 20],1,'z',{'Test','Test'},1,'n',struct('testfield',1),1);

%
% % getdefaults(...,'quiet',...);
% % getdefaults(variables,default_values,'quiet');
%

% getdefaults(vars,defaults,'quiet');
% getdefaults('quiet',vars,defaults);

%% Retrieve stored messages
log=writemessage('get');