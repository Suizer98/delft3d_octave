%DOUBLE2EVALSTR_TEST
% see also getHsig_t_test

quickstart internet
d = readTransectData('Jarkus Data','Noord-Holland','03000','2006');
xInitial    = d.xe(~isnan(d.ze)); %keep only the points with non-NaN z-values
zInitial    = d.ze(~isnan(d.ze)); %keep only the points with non-NaN z-values

disp(double2evalstr(xInitial))
disp(double2evalstr(zInitial,'precision','%4.2f'))
disp(double2evalstr(xInitial, zInitial))

disp(double2evalstr(zInitial+3))

disp(double2evalstr(roundoff(rand(5,5))))

disp(double2evalstr(roundoff(rand(5,5),2)))

disp(double2evalstr([1; 1; 1]))



