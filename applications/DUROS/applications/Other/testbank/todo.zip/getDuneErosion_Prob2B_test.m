%GETDUNEEROSION_PROB2B_TEST test function for getDuneErosion_Prob2B
% clear all; close all; %clc

%% input
% PD50=0.617911; PWL_t=0.5; PHsig_t=0.5; PTp_t=0.99; PProfileFluct=0.5; PDuration=0.6; PGust=0.5; PAccuracy=0.6; maxRD=[];
% CaseNrs = 0:7;
% FD50=0.025; FWL_t=0.991845; FHsig_t=0.1; FTp_t=0; FProfileFluct=0.9; FDuration=0.025; FGust=0.025; FAccuracy=0.025; CaseNrs=9;
% PD50=0.5; PWL_t=0.5; PHsig_t=0.5; PTp_t=0.5; PProfileFluct=0.5; PDuration=0.5; PGust=0.5; PAccuracy=0.617911; CaseNr=10;
% PD50=0.617911; PWL_t=0.5; PHsig_t=0.5; PTp_t=0.5; PProfileFluct=0.5; PDuration=0.5; PGust=0.5; PAccuracy=0.5; CaseNr=10;
PD50=0.202987; PWL_t=0.999998; PHsig_t=0.690294; PTp_t=0.571985; PProfileFluct=0.338097; PDuration=0.709064; PGust=0.5; PAccuracy=0.795592; CaseNrs=58;

%% Calculate:
for CaseNr = CaseNrs
%     plotSensitivity(CaseNr, pwd)
    maxRD =[];
    try
        [RD, maxRD, result, WL_t] = getDuneErosion_Prob2B(PD50, PWL_t, PHsig_t, PTp_t, PProfileFluct, PDuration, PGust, PAccuracy, maxRD, CaseNr); %#ok<NASGU>
    catch
        fclose all;
        s = lasterror;
        fprintf('\nWhen using input:\nPD50=%g; PWL_t=%g; PHsig_t=%g; PTp_t=%g; PProfileFluct=%g; PDuration=%g; PGust=%g; PAccuracy=%g; maxRD=%g; CaseNr=%g;\n',[PD50, PWL_t, PHsig_t, PTp_t, PProfileFluct, PDuration, PGust, PAccuracy, maxRD, CaseNr]);
        fileseplocations = strfind(s.stack(1).file, filesep); % find positions of file separators
        linestr=['<a href="error:' s.stack(1).file ',' num2str(s.stack(1).line) ',1">' s.stack(1).file(fileseplocations(end)+1:end) '</a>'];
        fprintf('In file %s at line %.0f an error occured:\n%s\n',linestr, s.stack(1).line, s.message)
        [RD, maxRD] = deal(0); %#ok<NASGU> % dummy value for RD and maxRD
        fprintf('  Warning: RD has been set to dummy value zero\n')
    end

%% Visualize results:
%     for i = 1 : length(result)
%         if isfield(result(i).info,'precision')
%             disp([result(i).info.ID,': Accuracy: ' num2str(result(i).info.precision,'%02.4f') ' NrIter: ' num2str(result(i).info.iter)]);
%         end
%         if ismember({result(i).info.ID},'Additional Erosion')
%             disp (['Xp = ' num2str(result(i).xActive(min(find(result(i).z2Active == WL_t))),'%.2f'),' m'])
%             disp (['Xr = ' num2str(result(i).xActive(1),'%.2f'),' m'])
%         end
%     end
    disp(['RD = ' num2str(RD,'%.1f'),' m; WL_t = ' num2str(WL_t,'%.2f'),' m'])
    disp(' ')
%     plotDuneErosion(result, CaseNr+1)
end