%GETWATERLEVEL_TEST test function for getWaterlevel
clear; close all; clc
%% Input:
mu      = 0;
sigma   = 1;
steps   = 20;

%% Calculate:
distribution = getNormalDistribution(mu, sigma, steps);

%% Visualize results:
figure('NumberTitle','off',...
    'Name','Test getNormalDistribution',...
    'Color','w');

ydistribution = normpdf(distribution, mu, sigma);
scatter(distribution,ydistribution,'Marker','o','MarkerFaceColor','k','MarkerEdgeColor','k')
hold on

prob = (0.0002:0.0004:0.9998)';
x = norminv(prob,mu,sigma);
y = normpdf(x,mu,sigma);
plot(x,y)

prob2 = 0 : 1/steps : 1;
for i=1:length(prob2)-1
    xstep = (prob2(i+1)-prob2(i))/1000;
    prob3 = prob2(i)+xstep : xstep : prob2(i+1);
    if i == length(prob2)-1
        prob3 = prob3(1:end-1);
    end
    x = norminv(prob3,mu,sigma);
    y = normpdf(x,mu,sigma);
    probpatch = [x' y'; fliplr(x)' zeros(length(y),1)];
    if odd(i)==1
        color='b';
    else
        color='r';
    end
    patch(probpatch(:,1), probpatch(:,2), ones(size(probpatch(:,2))),color)
end


legend('Discrete represented distribution points')
title('Test figure getNormalDistribution');
grid on
axis tight
hold off

