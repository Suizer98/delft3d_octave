%GETDUROSPROFILE_TEST test function for getDUROSprofile
clear all; close all; clc
%% Input:
xInitial = [-200 -24.375 5.625 55.725 230.625 1950]';
zInitial = [15 15 3 0 -3 -14.4625]';
x0 = -47.2;
Hsig_t = 9;
Tp_t = 12;
WL_t = 5;
w = .0247;

%% Calculate:
result = getDUROSprofile(xInitial, zInitial, x0, Hsig_t, Tp_t, WL_t, w);

newpointsid = ~ismember(result.xActive,xInitial);
usedpointsid = ismember(result.xActive,xInitial);

%% Visualize results:
try close('Test DUROSprofile'); end %#ok<TRYNC>
figure('NumberTitle','off',...
    'Name','Test DUROSprofile',...
    'Color','w');

hold on
grid on
box on

h(1)=plot(xInitial,zInitial,'bx--');
h(2)=plot(result.xActive, result.z2Active,'Color','k','LineStyle','-','LineWidth',2);
h(3)=scatter(result.xActive(newpointsid),result.z2Active(newpointsid),'Marker','o','MarkerEdgeColor','r');
    h(3)=scatter(result.xActive(newpointsid),result.zActive(newpointsid),'Marker','o','MarkerEdgeColor','r');
h(4)=scatter(result.xActive(usedpointsid),result.z2Active(usedpointsid),'Marker','o','MarkerEdgeColor','b');


legend(h,{'Initial profile','DUROS profile','Points at additional x-locations','Points at original x-locations'},1);

xlabel('x-coordinate');
ylabel('z-coordinate','Rotation',270);
title('Test figure getDUROSprofile');

hold off