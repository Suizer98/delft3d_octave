%GETMKL_TEST test function for getMKL
clear; close all; clc
ids = 1:2;
tic
for id = ids
    
%% Input:
    if id==1
        try
            load('JarkusData_Noord-Holland_03000_2006.mat');
        catch
            currentpath = pwd;
            quickstart internet
            cd(currentpath);
            d = readTransectData('Jarkus Data','Noord-Holland','03000','2006');
        end
        xInitial=d.xe(~isnan(d.ze)); %keep only the points with non-NaN z-values
        zInitial=d.ze(~isnan(d.ze)); %keep only the points with non-NaN z-values
        SeawardBoundary = -75;
    end
    if id==2
        xInitial    = [-200 -24.375 5.625 55.725 230.625 1950]';
        zInitial    = [15 15 3 0 -3 -14.4625]';
        SeawardBoundary = [];
    end
    low = -1;
    high = 16;
        
%% Calculate:
    [xMKL(id), result(id), Boundaries(id)] = getMKL(xInitial, zInitial, high, low, SeawardBoundary); %#ok<AGROW>

    zMKL(id) = interp1(xInitial, zInitial, xMKL(id)); %#ok<AGROW>
    
%% Visualize results:
    if ~isnan(xMKL(id))
        figure(id)
        plot(xInitial, zInitial,'k')
        xlabel('cross shore distance to RSP [m]')
        ylabel('height to NAP [m]','Rotation',270,'VerticalAlignment','bottom')
        title('Test figure getMKL');
        hold on
        volumepatch = [result(id).xActive' fliplr(result(id).xActive'); result(id).z2Active' fliplr(result(id).zActive')]';
        hp=patch(volumepatch(:,1), volumepatch(:,2), ones(size(volumepatch(:,2)))*-(length(result(id))),'b');
        scatter(xMKL(id),zMKL(id),'Marker','o','MarkerFaceColor','k','MarkerEdgeColor','k','SizeData',4)
        hold off
        disp(['xMKL = ', num2str(xMKL(id),'%.2f'),' m'])
        disp(' ')
    end
end
toc