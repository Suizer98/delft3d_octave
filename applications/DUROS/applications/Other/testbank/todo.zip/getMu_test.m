%GETMU_test     test routine for getMu
clear; close all; clc

%% Input:
try
    alfa = 727.86; beta = 3.01; Pmin = 1e-7; Pmax = 1e-2; steps = 25; % these are input arguments for getWaterlevel
    WL_t = getWaterlevel(alfa, beta, Pmin, Pmax, steps); % this gives a series of 25 water levels as applied in the numerical integration of Van de Graaff (1984), see getWaterlevel_test.m
catch
    WL_t = [3.78713 3.94012 4.09312 4.24612 4.39911 4.55211 4.7051 4.8581 5.01109 5.16409 5.31709 5.47008 5.62308 5.77607 5.92907 6.08206 6.23506 6.38806 6.54105 6.69405 6.84704 7.00004 7.15303 7.30603 7.45903 ];
end

%% Calculate:
muHsig_t = getMu(WL_t);

%% Visualize results:
figure('NumberTitle','off',...
    'Name','Test getMu',...
    'Color','w');

fh = plot(WL_t, muHsig_t);
xlabel('Water level (WL_t) w.r.t. NAP [m]');
ylabel('Mean wave height (muHsig_t) [m]','Rotation',270,'VerticalAlignment','top');
title('Test figure getMu');
grid on
axis tight