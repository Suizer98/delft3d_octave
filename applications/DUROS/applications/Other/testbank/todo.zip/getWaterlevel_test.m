%GETWATERLEVEL_TEST test function for getWaterlevel
clear; close all; clc
%% Input:
alfa = 727.86; % (=e^(lambda*epsilon)) in which epsilon is the offset of the exponential distribution
lambda = 3.01; % rate parameter of the exponential distribution (=1/beta)
Pmin = 1e-7;
Pmax = 1e-2;
steps = 25;

epsilon = log(alfa)/lambda; % offset of exponential function
beta    = 1/lambda; % Alternate parameterization is used in matlab functions 

%% Calculate:
WL_t = [getWaterlevel(alfa, lambda, Pmax, Pmax,1) getWaterlevel(alfa, lambda, Pmin, Pmin,1)];
WL_t = min(WL_t) : diff(WL_t)/steps : max(WL_t); % outer boundaries for waterlevel intervals
[WL_t2, p] = getWaterlevel(alfa, lambda, Pmin, Pmax, steps); % probability of occurance for each waterlevel
P_Exc = 1-expcdf(WL_t-epsilon, beta); % probability of exceedance for each waterlevel (= 1 - cdf)

%% Visualize results:
figure('NumberTitle','off',...
    'Name','Test getWaterlevel',...
    'Color','w');

plot([Pmax Pmin],WL_t([1 end]),':')
set(gca,'XScale','log','XDir','reverse');
xlabel('Probability of exceedance per year');
ylabel('Maximum waterlevel w.r.t. NAP [m]','Rotation',270,'VerticalAlignment','top');
title('Test figure getWaterlevel');
grid on
hold on
axis tight
for i = 1 : length(WL_t)-1
    plot(P_Exc(i:i+1),WL_t2([i i]),'LineWidth',2)
    hold on;
end
YTickLabel = cell(size(WL_t2));
for i = 1:length(WL_t2)
    YTickLabel{i} = num2str(WL_t2(i),'%.2f');
end
set(gca,'YTick',WL_t2,'YTickLabel',YTickLabel);
hold off