%GETVOLUME_TEST   test routine for getVolume
clear; close all; clc
ids = 1:2;
tic
for id = ids

    %% Input:
    try
        load('JarkusData_Noord-Holland_03000_2006.mat');
    catch
        currentpath = pwd;
        quickstart internet
        cd(currentpath);
        d = readTransectData('Jarkus Data','Noord-Holland','03000','2006');
    end

    if id==1
        [UpperBoundary, LowerBoundary, LandwardBoundary, SeawardBoundary, x2, z2] = deal([]);
    end

    if id==2
        [UpperBoundary, LowerBoundary, LandwardBoundary, SeawardBoundary, x2, z2] = deal([], -5, -500, 700, [], []);
    end

    %% Calculate:
    [Volume(id), result(id), Boundaries] = getVolume(d.xe, d.ze, UpperBoundary, LowerBoundary, LandwardBoundary, SeawardBoundary, x2, z2); %#ok<AGROW,AGROW>

    %% Visualize results:

    result(id).info.ID = 'Volume'; %#ok<AGROW>
    [result(id).zActive, result(id).z2Active] = deal(result(id).z2Active, result(id).zActive); %#ok<AGROW,AGROW> %ToDo: make the result structure that generic that this swap action is redundant for plotDuneErosion
    fh = figure;clf
    plotVolume(result(id), fh);
    hold on
    plot(d.xe(~isnan(d.ze)), d.ze(~isnan(d.ze)),'-k')
    hold off
end
toc

